import numpy as np

mat = [[1,2],[3,4]]
r = int(input("Enter the number of rows: "))
c = int(input("Enter the number of columns: "))

# The len(matrix) will give the number of the rows.
# The len(matrix[0]) will give the number of columns.

def reshape_matrix(matrix, rows, columns):
    print(len(mat))
    print(len(matrix[0]))
    if rows * columns == len(matrix) * len(matrix[0]):
        return np.reshape(matrix, (rows,columns))
    else:
        return matrix

print(reshape_matrix(mat, r, c))
